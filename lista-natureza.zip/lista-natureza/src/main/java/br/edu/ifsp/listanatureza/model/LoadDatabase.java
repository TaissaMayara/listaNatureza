package br.edu.ifsp.listanatureza.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoadDatabase {
    private static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

    @Bean
    CommandLineRunner initDataBase(AnimalRepository repository){
        return args->{
            Animal animal1 = new Animal("Panda","Ailuropoda melanoleuca","Branco e Preto", "20 anos");
            Animal animal2 = new Animal("Coala","P. Cinereus","Cinza claro", "18 anos");
            Animal animal3 = new Animal("Elefante-asiático","Elephas maximus","Cinza-chumbo", "48 anos");
            
            // List<Planta> plantas =  new ArrayList<>();

            Planta planta1 = new Planta("Bambu-preto", "Phyllostachys nigra muchisasa", "Preto");
            Planta planta2 = new Planta("Raízes", "Raíz axial", "Marrom");
            Planta planta3 = new Planta("Eucalipto", "Eucalyptus globulus", "Verde");
            
            // plantas.add(planta1);
            // plantas.add(planta2);
            // plantas.add(planta3);   

            //Vou adicionar novas plantas aqui
            // animal1.setPlantas(plantas);
            // animal2.setPlantas(plantas);
            // animal3.setPlantas(plantas);

            /* Novo código que adiciona cada planta por vez nos animais */
            animal1.addPlanta(planta1);
            animal1.addPlanta(planta2);
            animal1.addPlanta(planta3);

            animal2.addPlanta(planta1);
            animal2.addPlanta(planta2);
            animal2.addPlanta(planta3);

            animal3.addPlanta(planta1);
            animal3.addPlanta(planta2);
            animal3.addPlanta(planta3);

            log.info("Inserindo: " + repository.save(animal1));
            log.info("Inserindo: " + repository.save(animal2));
            log.info("Inserindo: " + repository.save(animal3));          
        };
    }
}
