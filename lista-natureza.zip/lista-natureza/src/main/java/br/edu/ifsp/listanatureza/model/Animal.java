package br.edu.ifsp.listanatureza.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.JoinColumn;

@Entity
public class Animal {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private Long id;
    private String nome;
    private String especie;
    private String cor;
    private String expectativaVida;
    //private List<Planta> plantas;

    //CARDINALIDADE JPA - MUITOS PARA MUITOS
    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(name = "associacao_animal_planta", 
            joinColumns = @JoinColumn(name = "fk_animal"), 
            inverseJoinColumns = @JoinColumn(name = "fk_planta"))
    @JsonManagedReference
    private List<Planta> plantas;
    

    //Construtor vazio
    public Animal() {
        
    }
    
    // Construtor
    public Animal(String nome, String especie, String cor, String expectativaVida) {
        this.nome = nome;
        this.especie = especie;
        this.cor = cor;
        this.expectativaVida = expectativaVida;
        /* instanciar a Lista na criação do objeto */
        this.plantas = new ArrayList<>();
    }

    //Métodos Getters e Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEspecie() {
        return especie;
    }
    public void setEspecie(String especie) {
        this.especie = especie;
    }
    public String getCor() {
        return cor;
    }
    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getExpectativaVida() {
        return expectativaVida;
    }

    public void setExpectativaVida(String expectativaVida) {
        this.expectativaVida = expectativaVida;
    }

    public List<Planta> getPlantas() {
        return plantas;
    }

    public void setPlantas(List<Planta> plantas) {
        this.plantas = plantas;
    }
    
    /* Remove uma única planta */
    public void removePlanta(Planta planta) {
        plantas.remove(planta);
        planta.getAnimais().remove(this);
    }

    /* Adiciona uma única planta */
    public void addPlanta(Planta planta) {
        plantas.add(planta);
        planta.getAnimais().add(this);
    }
}
