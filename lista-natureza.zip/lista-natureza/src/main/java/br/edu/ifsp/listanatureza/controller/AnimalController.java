package br.edu.ifsp.listanatureza.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ifsp.listanatureza.model.Animal;
import br.edu.ifsp.listanatureza.model.AnimalRepository;

@RestController
public class AnimalController {
 
    @Autowired
    AnimalRepository animalRepository;

    @GetMapping("/listasFauna")
    public List<Animal> getListasFauna(){
        return (List<Animal>) animalRepository.findAll();
    }
    @PostMapping("/listasFauna/criar")
    public Animal postLista(@RequestBody Animal animal){
        return animalRepository.save(animal);
    }
    @PutMapping("/listasFauna/alterar_fauna/{id}")
      public Animal putAnimal(@PathVariable Long id, @RequestBody Animal animal){
          if(animalRepository.findById(id).isPresent()){
              Animal animalBanco = animalRepository.findById(id).get();
              animalBanco.setNome(animal.getNome());
              animalBanco.setEspecie(animal.getEspecie());
              animalBanco.setCor(animal.getCor());
              animalBanco.setExpectativaVida(animal.getExpectativaVida());
              animalRepository.save(animalBanco);         
              return animal;
          }
          return null;
      }
    @GetMapping("/listasFauna/{id}")
      @ResponseBody
      public Animal getAnimalById(@PathVariable("id") Animal animal){
          return animal;
    }
    @DeleteMapping("/listasFauna/deletar_fauna/{id}")
      public Animal deleteAnimal(@PathVariable Long id){
          if(animalRepository.findById(id).isPresent()){
              Animal animal = animalRepository.findById(id).get();
              animalRepository.delete(animal);
              return animal;
          }
          return null;
        }
    }

